module.exports = {
  HOST: "localhost",
  USER: "root",
  PASSWORD: "1234",  // change this to your actual MySQL root password
  DB: "event_db",
  dialect: "mysql"
};
